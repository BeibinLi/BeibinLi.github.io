-- Keymaps (translated from your .vimrc + modern additions)
local map = vim.keymap.set

-- Better defaults
map("n", "<Esc>", "<cmd>nohlsearch<CR>", { desc = "Clear search highlight" })

-- Ctrl-J to break line (your vimrc mapping)
map("n", "<C-j>", "i<CR><Esc>", { desc = "Break line at cursor" })

-- F2 to open config (updated for nvim)
map("n", "<F2>", "<cmd>e ~/.config/nvim/init.lua<CR>", { desc = "Open nvim config" })

-- F5 to run files (will be set per filetype in autocmds, but here's a generic one)
map("n", "<F5>", function()
  local ft = vim.bo.filetype
  local cmd = {
    python = "python3 %",
    lua = "lua %",
    sh = "bash %",
    javascript = "node %",
    typescript = "ts-node %",
    rust = "cargo run",
  }
  if cmd[ft] then
    vim.cmd("w")
    vim.cmd("!" .. cmd[ft])
  else
    print("No run command for filetype: " .. ft)
  end
end, { desc = "Run current file" })

-- Window navigation (if not using tmux-navigator plugin)
map("n", "<C-h>", "<C-w>h", { desc = "Go to left window" })
map("n", "<C-l>", "<C-w>l", { desc = "Go to right window" })
map("n", "<C-k>", "<C-w>k", { desc = "Go to upper window" })
-- Note: <C-j> is used for line break, so we skip it here

-- Better movement on wrapped lines
map("n", "j", "gj", { silent = true })
map("n", "k", "gk", { silent = true })

-- Keep cursor centered when scrolling
map("n", "<C-d>", "<C-d>zz", { desc = "Scroll down and center" })
map("n", "<C-u>", "<C-u>zz", { desc = "Scroll up and center" })
map("n", "n", "nzzzv", { desc = "Next search result centered" })
map("n", "N", "Nzzzv", { desc = "Previous search result centered" })

-- Better indenting in visual mode
map("v", "<", "<gv")
map("v", ">", ">gv")

-- Move lines up/down
map("v", "J", ":m '>+1<CR>gv=gv", { desc = "Move selection down" })
map("v", "K", ":m '<-2<CR>gv=gv", { desc = "Move selection up" })

-- Quick save
map("n", "<leader>w", "<cmd>w<CR>", { desc = "Save file" })
map("n", "<leader>q", "<cmd>q<CR>", { desc = "Quit" })

-- Buffer navigation
map("n", "<S-h>", "<cmd>bprevious<CR>", { desc = "Previous buffer" })
map("n", "<S-l>", "<cmd>bnext<CR>", { desc = "Next buffer" })
map("n", "<leader>bd", "<cmd>bdelete<CR>", { desc = "Delete buffer" })

-- Diagnostic navigation (for LSP)
map("n", "[d", vim.diagnostic.goto_prev, { desc = "Previous diagnostic" })
map("n", "]d", vim.diagnostic.goto_next, { desc = "Next diagnostic" })
map("n", "<leader>e", vim.diagnostic.open_float, { desc = "Show diagnostic" })

-- Quickfix navigation
map("n", "[q", "<cmd>cprev<CR>", { desc = "Previous quickfix" })
map("n", "]q", "<cmd>cnext<CR>", { desc = "Next quickfix" })
