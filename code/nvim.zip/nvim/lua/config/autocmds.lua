-- Autocommands (translated from your .vimrc)
local autocmd = vim.api.nvim_create_autocmd
local augroup = vim.api.nvim_create_augroup

-- General settings group
local general = augroup("General", { clear = true })

-- Highlight on yank
autocmd("TextYankPost", {
  group = general,
  callback = function()
    vim.highlight.on_yank({ higroup = "IncSearch", timeout = 200 })
  end,
})

-- Auto-reload files when changed externally
autocmd({ "FocusGained", "BufEnter", "CursorHold" }, {
  group = general,
  command = "checktime",
})

-- Return to last edit position when opening files
autocmd("BufReadPost", {
  group = general,
  callback = function()
    local mark = vim.api.nvim_buf_get_mark(0, '"')
    local lcount = vim.api.nvim_buf_line_count(0)
    if mark[1] > 0 and mark[1] <= lcount then
      pcall(vim.api.nvim_win_set_cursor, 0, mark)
    end
  end,
})

-- Filetype-specific settings
local filetypes = augroup("FileTypes", { clear = true })

-- Python: 4 spaces
autocmd("FileType", {
  group = filetypes,
  pattern = "python",
  callback = function()
    vim.opt_local.tabstop = 4
    vim.opt_local.shiftwidth = 4
    vim.opt_local.expandtab = true
  end,
})

-- Markdown/Text files: wrap, spell check, no colorcolumn (your preferences)
autocmd("FileType", {
  group = filetypes,
  pattern = { "markdown", "text", "tex", "rmd" },
  callback = function()
    vim.opt_local.wrap = true
    vim.opt_local.linebreak = true
    vim.opt_local.spell = true
    vim.opt_local.colorcolumn = ""
  end,
})

-- Treat .md and .rmd as markdown
autocmd({ "BufNewFile", "BufRead" }, {
  group = filetypes,
  pattern = { "*.md", "*.rmd", "*.txt" },
  callback = function()
    vim.bo.filetype = "markdown"
  end,
})

-- Don't write backup for crontab and chpass
autocmd("BufWrite", {
  group = general,
  pattern = { "/private/tmp/crontab.*", "/private/etc/pw.*" },
  callback = function()
    vim.opt_local.writebackup = false
  end,
})

-- Resize splits when window is resized
autocmd("VimResized", {
  group = general,
  callback = function()
    vim.cmd("tabdo wincmd =")
  end,
})

-- Close some filetypes with just 'q'
autocmd("FileType", {
  group = general,
  pattern = { "help", "man", "qf", "lspinfo", "startuptime", "checkhealth" },
  callback = function(event)
    vim.bo[event.buf].buflisted = false
    vim.keymap.set("n", "q", "<cmd>close<CR>", { buffer = event.buf, silent = true })
  end,
})
