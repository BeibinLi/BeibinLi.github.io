-- Options (translated from your .vimrc)
local opt = vim.opt

-- Encoding
opt.encoding = "utf-8"
opt.fileencoding = "utf-8"
opt.fileformat = "unix"

-- Line numbers
opt.number = true
opt.relativenumber = true  -- Modern addition: relative line numbers

-- Tabs and spaces (your preference: 2 spaces)
opt.tabstop = 2
opt.softtabstop = 2
opt.shiftwidth = 2
opt.expandtab = true
opt.smarttab = true
opt.smartindent = true
opt.autoindent = true

-- Show invisible characters (like your vimrc)
opt.list = true
opt.listchars = { tab = "~ ", eol = "¬", trail = "·", extends = "»", precedes = "«" }

-- Cursor
opt.cursorline = true
opt.ruler = true
opt.colorcolumn = "100"

-- Scrolling (your preferences)
opt.scrolloff = 8
opt.sidescrolloff = 15
opt.sidescroll = 1

-- Searching (your preferences)
opt.hlsearch = true
opt.incsearch = true
opt.ignorecase = true
opt.smartcase = true

-- Wildmenu
opt.wildmenu = true
opt.wildmode = "full"

-- Split behavior
opt.splitright = false  -- Your preference: split left
opt.splitbelow = true

-- Misc
opt.hidden = true
opt.autoread = true
opt.backup = false
opt.writebackup = false
opt.swapfile = false
opt.undofile = true
opt.undodir = vim.fn.stdpath("data") .. "/undo"

-- Better UI
opt.termguicolors = true
opt.signcolumn = "yes"
opt.updatetime = 250
opt.timeoutlen = 300

-- Backspace behavior
opt.backspace = "indent,eol,start"

-- Search path (like your :find settings)
opt.path:append("**")
opt.suffixesadd:append({ ".py", ".cpp", ".h", ".lua", ".js", ".ts" })

-- Spell (will be enabled for specific filetypes in autocmds)
opt.spelllang = "en_us"

-- Disable modelines for security
opt.modelines = 0

-- Clipboard integration
opt.clipboard = "unnamedplus"

-- Mouse support (optional, but useful in modern nvim)
opt.mouse = "a"

-- Completion
opt.completeopt = "menu,menuone,noselect"

-- Wrap settings (will be overridden for text files in autocmds)
opt.wrap = false
opt.linebreak = true
