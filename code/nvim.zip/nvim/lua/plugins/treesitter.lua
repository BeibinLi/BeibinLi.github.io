-- Treesitter (modern syntax highlighting)
return {
  {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate",
    config = function()
      local parsers = {
        "bash", "c", "cpp", "css", "dockerfile", "html",
        "javascript", "json", "lua", "markdown", "markdown_inline",
        "python", "rust", "toml", "tsx", "typescript", "vim", "vimdoc", "yaml",
      }

      -- Install missing parsers (deferred to avoid blocking startup)
      vim.defer_fn(function()
        local ts = require("nvim-treesitter")
        local installed = ts.get_installed()
        local to_install = vim.tbl_filter(function(p)
          return not vim.list_contains(installed, p)
        end, parsers)
        if #to_install > 0 then
          ts.install(to_install)
        end
      end, 100)

      -- Enable treesitter-based highlighting (built into Neovim 0.11+)
      vim.api.nvim_create_autocmd("FileType", {
        callback = function()
          pcall(vim.treesitter.start)
        end,
      })

      -- Enable treesitter-based indentation
      vim.api.nvim_create_autocmd("FileType", {
        callback = function()
          vim.bo.indentexpr = "v:lua.require'nvim-treesitter'.indentexpr()"
        end,
      })
    end,
  },

  -- Treesitter context (shows current function/class at top)
  {
    "nvim-treesitter/nvim-treesitter-context",
    config = function()
      require("treesitter-context").setup({
        enable = true,
        max_lines = 3,
      })
    end,
  },
}
