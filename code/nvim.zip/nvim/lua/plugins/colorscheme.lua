-- Colorscheme (Monokai - matching your vim preference)
return {
  {
    "loctvl842/monokai-pro.nvim",
    lazy = false,
    priority = 1000,
    config = function()
      require("monokai-pro").setup({
        transparent_background = false,
        terminal_colors = true,
        devicons = true,
        filter = "pro", -- classic, octagon, pro, machine, ristretto, spectrum
        styles = {
          comment = { italic = true },
          keyword = { italic = false },
          type = { italic = false },
        },
        inc_search = "background",
        background_clear = {},
      })
      vim.cmd.colorscheme("monokai-pro")
    end,
  },
}
