-- Neovim Configuration
-- Migrated from ~/.vimrc with modern Lua-based setup

-- Bootstrap lazy.nvim plugin manager
require("config.lazy")

-- Core settings (options, keymaps, autocmds)
require("config.options")
require("config.keymaps")
require("config.autocmds")
